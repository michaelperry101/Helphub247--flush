export default function Contact(){
  return (
    <div style={{padding:24,maxWidth:900,margin:'0 auto'}}>
      <h1>Contact Us</h1>
      <p>Email: <strong>support@helphub247.co.uk</strong></p>
      <p>For privacy requests please email <strong>support@helphub247.co.uk</strong></p>
    </div>
  )
}
